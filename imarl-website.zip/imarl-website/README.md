# IMARL Technologies website

A single-page marketing site for IMARL Technologies with a claymorphism look, real 3D (Three.js) and a glass navigation bar.

## Sections
Hero with interactive 3D clay sculpture, About, Services, Innovation Lab (live 3D blob), Selected Projects (demonstration concepts), Process (Discover, Design, Develop, Deliver), Contact, Footer.

## Run locally
No build step. Open `index.html` in a browser, or serve the folder:

```
python3 -m http.server 8080
```

Then visit http://localhost:8080. An internet connection is needed for Three.js (cdnjs) and Google Fonts.

## Before you publish: edit these placeholders
1. **Contact email:** in `index.html`, search for `TO=` and replace `hello@your-domain.example`. The form opens the visitor's email app addressed to this address.
2. **About and footer:** replace the yellow `[...]` placeholders (founding story, team size, location, email, phone).
3. **Projects:** the three projects are labelled "Demonstration concept". Replace them with real case studies when available.

No company history, clients, awards or testimonials have been invented.

## Deploy
- **GitHub Pages:** repo Settings → Pages → deploy from branch `main`, folder `/ (root)`.
- **Netlify / Vercel / Cloudflare Pages:** drag the folder in or connect the repo; no build command, publish directory is the repo root.

## Tech
HTML, CSS and vanilla JavaScript. Three.js r128 (cdnjs). Fonts: Bricolage Grotesque and Fraunces (Google Fonts).
Supports light/dark mode, keyboard navigation, a skip link and `prefers-reduced-motion`.

## Customise
- Colours and type: CSS variables at the top of the `<style>` block in `index.html`.
- Services: the `S` array in the script.
- 3D scenes: the two `scene(...)` calls (hero and lab).
